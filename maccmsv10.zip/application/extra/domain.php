<?php
return array (
  'wan.51la.link' => 
  array (
    'site_url' => 'wan.51la.link',
    'site_name' => '樱花动漫_分享精彩的新番日漫',
    'site_keywords' => '樱花动漫,樱花动漫网,樱花动漫官网,日本动漫',
    'site_description' => '樱花动漫拥有最新热门清晰画质的在线动漫，观看完全免费、无须注册、无广告弹窗、高速播放、更新及时的专业在线樱花动漫站，努力为所有动漫迷们提供最好看的动漫。',
    'template_dir' => 'stui_tpl',
    'html_dir' => 'html',
    'ads_dir' => 'ads',
  ),
);