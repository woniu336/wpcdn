<?php
return array (
  0 => 
  array (
    'name' => 'ikun资源站',
    'rema' => '支持HTTPS,极速秒播',
    'flag' => 'ikunzy',
    'apis' => 'https://ikunzyapi.com/api.php/provide/vod/from/ikm3u8/at/json/',
    'zylink' => 'https://ikunzy.com/',
    'coll' => 'ik播放器,ikm3u8,1233,1',
    'type' => '2',
    'filter' => '0',
    'filter_from' => '',
    'opt' => '0',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
  ),
  1 => 
  array (
    'name' => '淘片资源站',
    'rema' => 'HTTPS资源,m3u8直链',
    'flag' => 'taopianzy',
    'apis' => 'https://taopianapi.com/cjapi/mc10/vod/json.html',
    'zylink' => 'https://www.taopianzy.com/home/index.html?mengya-1',
    'coll' => '淘片播放器,tpm3u8,1030,1',
    'type' => '2',
    'filter' => '0',
    'filter_from' => '',
    'opt' => '0',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
  ),
  2 => 
  array (
    'name' => '天空资源站',
    'rema' => '集团出资,全网最快',
    'flag' => 'tiankong',
    'apis' => 'https://m3u8.tiankongapi.com/api.php/provide/vod/at/xml/',
    'zylink' => 'http://tiankongzy.com/',
    'coll' => '天空在线,tkm3u8,1111,1',
    'type' => '1',
    'filter' => '0',
    'filter_from' => '',
    'opt' => '0',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
  ),
  3 => 
  array (
    'name' => '新浪资源站',
    'rema' => '更新最快,极速CDN,全网秒播',
    'flag' => 'xinlangzy',
    'apis' => 'https://api.xinlangapi.com/xinlangapi.php/provide/vod/from/xlm3u8/at/json/',
    'zylink' => 'https://www.xinlangzy.net/',
    'coll' => '新浪资源2,xlm3u8,1219,1',
    'type' => '2',
    'filter' => '0',
    'filter_from' => '',
    'opt' => '0',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
  ),
);