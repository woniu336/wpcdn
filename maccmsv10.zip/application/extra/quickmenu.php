<?php
return array (
  0 => '文章管理,art/data',
  1 => '行分隔符,###',
  2 => '系统设置,system/config',
  3 => '视频管理,vod/data',
  4 => '采集管理,/laojiuba.php/admin/collect/index.html',
  5 => '定时采集,/laojiuba.php/admin/timming/index.html',
  6 => '萌芽采集资源,mycj/union',
);