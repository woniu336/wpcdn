<?php
return array (
  'aa' => 
  array (
    'id' => 'aa',
    'status' => '0',
    'name' => 'aa',
    'des' => '采集今日数据',
    'file' => 'collect',
    'param' => 'ac=cjday&xt=1&ct=&rday=24&cjflag=tv6_com&cjurl=http://cj2.tv6.com/mox/inc/youku.php',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1597629775,
  ),
  'bb' => 
  array (
    'status' => '0',
    'name' => 'bb',
    'des' => '生成首页',
    'file' => 'make',
    'param' => 'ac=index',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'id' => 'bb',
    'runtime' => 1535348998,
  ),
  'taopianzym3u818' => 
  array (
    '__token__' => '543f185da6fe77d2cb459b36835e3f97',
    'status' => '1',
    'name' => 'taopianzym3u818',
    'des' => '当日采集：淘片资源站【HTTPS资源,m3u8直链】',
    'file' => 'collect',
    'param' => 'ac=cj&h=24&cjflag=taopianzy&cjurl=https%3A%2F%2Ftaopianapi.com%2Fcjapi%2Fmc10%2Fvod%2Fjson.html',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
  'ikunzym3u821' => 
  array (
    '__token__' => 'e07f4a07947ab2ea72af2951c161297b',
    'status' => '1',
    'name' => 'ikunzym3u821',
    'des' => '当日采集：ikun资源站【支持HTTPS,极速秒播】',
    'file' => 'collect',
    'param' => 'ac=cj&h=24&cjflag=ikunzy&cjurl=https%3A%2F%2Fikunzyapi.com%2Fapi.php%2Fprovide%2Fvod%2Ffrom%2Fikm3u8%2Fat%2Fjson%2F',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
  'tiankongm3u811' => 
  array (
    '__token__' => '6f6bdadbfda777976e2602b6d64531f0',
    'status' => '1',
    'name' => 'tiankongm3u811',
    'des' => '当日采集：天空资源站【集团出资,全网最快】',
    'file' => 'collect',
    'param' => 'ac=cj&h=24&cjflag=tiankong&cjurl=https%3A%2F%2Fm3u8.tiankongapi.com%2Fapi.php%2Fprovide%2Fvod%2Fat%2Fxml%2F',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
  'xinlangzym3u804' => 
  array (
    '__token__' => 'f7d0bbc862c17804973fe8fd1c8c9f56',
    'status' => '1',
    'name' => 'xinlangzym3u804',
    'des' => '当日采集：新浪资源站【更新最快,极速CDN,全网秒播】',
    'file' => 'collect',
    'param' => 'ac=cj&h=24&cjflag=xinlangzy&cjurl=https%3A%2F%2Fapi.xinlangapi.com%2Fxinlangapi.php%2Fprovide%2Fvod%2Ffrom%2Fxlm3u8%2Fat%2Fjson%2F',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
);