<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:38:"template/stui_tpl/html/vod/search.html";i:1550497448;s:69:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/seo/vod_search.html";i:1705130330;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/include.html";i:1705074684;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/head.html";i:1705075051;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/page.html";i:1539164316;s:73:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/vod_box_rank.html";i:1550320472;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/foot.html";i:1705131122;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>搜索结果 - <?php echo $maccms['seo']['vod']['name']; ?></title>
<meta name="keywords" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>搜索结果" />
<meta name="description" content="<?php echo $param['wd']; ?><?php echo $param['actor']; ?><?php echo $param['director']; ?><?php echo $param['area']; ?><?php echo $param['lang']; ?><?php echo $param['year']; ?><?php echo $param['class']; ?>搜索结果" />   
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="/statics/img/favicon.ico" type="image/x-icon" />	
<link rel="stylesheet" href="/statics/font/iconfont.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block_color.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_default.css" type="text/css" />
<script type="text/javascript" src="//cdn.staticfile.org/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/stui_default.js"></script>
<script type="text/javascript" src="/statics/js/stui_block.js "></script>
<script type="text/javascript" src="/statics/js/home.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
	

</head>
<body>
	<header class="stui-header__top clearfix" id="header-top">
	<div class="container">	
		<div class="row">
			<div class="stui-header_bd clearfix">					
			    <div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"></a>										  
				</div>
				<div class="stui-header__side">					
					<ul class="stui-header__user">
						<?php if($maccms['user_status'] == 1): ?>
						<li>
							<a class="mac_user" href="javascript:;"><i class="icon iconfont icon-account"></i></a>
						</li>
						<?php else: ?>
						<li>
							<a href="javascript:;"><i class="icon iconfont icon-clock"></i></a>
							<div class="dropdown history">					
								<h5 class="margin-0 text-muted">
									<a class="historyclean text-muted pull-right" href="">清空</a>
									播放记录
								</h5>
								<ul class="clearfix" id="stui_history">
								</ul>
							</div>
						</li>
						<?php endif; ?>
					</ul>
					<script type="text/javascript" src="//lf3-cdn-tos.bytecdntp.com/cdn/expire-10-y/jquery-autocomplete/1.0.7/jquery.auto-complete.js"></script>
					<div class="stui-header__search"> 
				        <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();">
	    					<input type="text" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="请输入关键词..." autocomplete="off"/>
							<button class="submit" id="searchbutton" type="submit"><i class="icon iconfont icon-search"></i></button>							
						</form>
				  	</div>
				</div>									
				<ul class="stui-header__menu type-slide">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                <li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
	                <?php endforeach; endif; else: echo "" ;endif; ?>
	                <li <?php if($maccms['aid'] == 30): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_topic_index(); ?>">专题</a></li>
				</ul>				
			  </div>		 							    
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
	});
</script>

    <div class="container">
        <div class="row">
        	<div class="col-lg-wide-75 col-xs-1 padding-0">	
			   	<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">	
								<h3 class="title">
									<img src="<?php echo $maccms['path']; ?>statics/icon/icon_27.png"/>
									<?php echo $param['wd']; ?>
								</h3>
							</div>																		
						</div>
						<div class="stui-pannel_bd">
							<ul class="stui-vodlist__media col-pd clearfix">										
								<?php $__TAG__ = '{"num":"10","paging":"yes","pageurl":"vod\/search","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>		
								<li class="active <?php if($key > 1): ?>top-line-dot <?php endif; ?>clearfix">
									<div class="thumb">									
										<a class="v-thumb stui-vodlist__thumb lazyload" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>">
											<span class="play hidden-xs"></span>
											<span class="pic-text text-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
										</a>																												
									</div>
									<div class="detail">
								    	<h3 class="title"><a href="<?php echo mac_url_vod_detail($vo); ?>"><?php echo $vo['vod_name']; ?></a></h3>
								    	<p><span class="text-muted">导演：</span><?php echo mac_default($vo['vod_director'],'内详'); ?></p>
										<p><span class="text-muted">主演：</span><?php echo mac_default(mac_substring($vo['vod_actor'],18),'内详'); ?></p>
										<p class="hidden-mi"><span class="text-muted">类型：</span><?php echo $vo['vod_class']; ?><span class="split-line"></span><span class="text-muted">地区：</span><?php echo mac_default($vo['vod_area'],'内详'); ?><span class="hidden-xs"><span class="split-line"></span><span class="text-muted">年份：</span><?php echo mac_default($vo['vod_year'],'内详'); ?></span></p>		
										<p class="margin-0 ">
											<a class="btn btn-min btn-primary" href="<?php echo mac_url_vod_play($vo,['sid'=>1,'nid'=>1]); ?>">立即播放</a>&nbsp;&nbsp;<a class="btn btn-min btn-default" href="<?php echo mac_url_vod_detail($vo); ?>">查看详情</a>
										</p>												    	    																									
									</div>
								</li>							
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>						
						</div>
					</div>				
				</div>
				<?php if($__PAGING__['page_total'] > 1): ?>
<ul class="stui-page text-center clearfix">
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a></li>							
	<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
	<li class="hidden-xs <?php if($__PAGING__['page_current'] == $num): ?>active<?php endif; ?>"><a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li class="active visible-xs"><span class="num"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></span></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a></li>							
</ul>
<?php endif; ?><!-- 翻页 -->
			</div>
			<div class="col-lg-wide-25 stui-pannel-side hidden-md hidden-sm hidden-xs">	
				<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"1,2","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<div class="stui-pannel stui-pannel-bg clearfix">						
					<div class="stui-pannel-box">
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">
								<h3 class="title">
									<img src="<?php echo $maccms['path']; ?>statics/icon/icon_<?php echo $vo['type_id']; ?>.png"/>
									<?php echo $vo['type_name']; ?>热播榜
								</h3>																
							</div>
						</div>
						<div class="stui-pannel_bd clearfix">
							<ul class="stui-vodlist__text active col-pd clearfix">
								<?php $__TAG__ = '{"num":"10","paging":"no","type":"'.$vo['type_id'].'","order":"desc","by":"hits","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
									<li class="bottom-line-dot">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="text-muted pull-right hidden-md">
			<?php if($vo['vod_remarks'] != ''): ?><?php echo mac_substring($vo['vod_remarks'],8); elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
		</span>
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo mac_substring($vo['vod_name'],8); ?></a>
</li><!-- 列表-->	
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>
						</div>
					</div>						
				</div>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
        </div>
    </div>
	<div class="container">
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center hidden-xs"><span class="fontArial"> </span> 本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</a><br>
			<div class="col-pd text-center hidden-xs">联系邮箱：<a href="mailto:{maccms:email}"><?php echo $maccms['site_email']; ?></a></div>	</div>
			
			<p class="text-center hidden-xs">

			</p>			
			<p class="text-muted text-center visible-xs">本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</p>
		</div>
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;"><i class="icon iconfont icon-less"></i></a>
	</li>
	<li class="hidden-xs">
		<a class="copylink" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="visible-xs">
		<a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="hidden-xs">
		<span><i class="icon iconfont icon-qrcode"></i></span>
		<div class="sideslip">
			<div class="col-pd">
				<p id="qrcode"></p>
				<p class="text-center font-12">扫码用手机访问</p>
			</div>			
		</div>
	</li>
	<li>
		<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i></a>
	</li>
</ul>

<div class="hide"><?php echo $maccms['site_tj']; ?></div>
</body>
</html>
