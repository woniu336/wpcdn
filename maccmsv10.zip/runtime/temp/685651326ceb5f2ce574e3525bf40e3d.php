<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"template/stui_tpl/html/comment/ajax.html";i:1544526694;}*/ ?>
<div class="stui-pannel_bd text-center clearfix" style="padding: 50px 20px; line-height: 25px;">
	<h2>没有评论模板</h2>
	<p>
		您未下载或购买评论模板，请官网DIY市场内购买相应模板，如不需要显示请：后台/系统/评论留言配置/关闭评论即可
	</p>
</div>