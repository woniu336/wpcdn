<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:43:"template/stui_tpl/html/user/ajax_login.html";i:1544526674;}*/ ?>
<!--登录弹窗开始-->
<div class="stui-modal fade" id="modal-login" data-toggle="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="stui-modal__dialog">
        <div class="stui-modal__content">
            <div class="stui-pannel clearfix">
				<div class="stui-pannel-box clearfix">
					<div class="stui-pannel_hd">
						<div class="stui-pannel__head active bottom-line clearfix">
							<a href="javascript:;" class="more close pull-right" data-dismiss="modal" aria-hidden="true"><i class="icon iconfont icon-close"></i></a>
							<h3 class="title">
								登录账号
							</h3>
						</div>																		
					</div>
					<div class="stui-pannel_bd clearfix" style="padding: 50px 20px; line-height: 25px;">
						<h2 class="text-center">没有会员模板</h2>
						<p>
							您未购买DIY会员模板，请官网DIY市场内购买相应模板，如不需要显示请：后台/系统/会员参数配置/关闭会员即可
						</p>
					</div>		
				</div>
			</div>		
        </div>
    </div>
</div>
<!--登录弹窗结束-->
