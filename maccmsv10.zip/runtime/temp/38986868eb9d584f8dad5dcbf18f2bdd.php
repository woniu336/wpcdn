<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"/www/wwwroot/wan.51la.link/application/admin/view/extend/upload/alibaba.html";i:1638900274;}*/ ?>
<div class="layui-form-item upload_mode mode_Alibaba" <?php if($config['upload']['mode'] != 'Alibaba'): ?>style="display:none;" <?php endif; ?>>
<label class="layui-form-label">阿里巴巴图床：</label>
<div class="layui-input-block">
    <a href="http://alibaba.com" target="_blank" class="layui-btn layui-btn-primary">目前免费不用申请</a>
</div>
</div>
<div class="layui-form-item upload_mode mode_Alibaba" <?php if($config['upload']['mode'] != 'Alibaba'): ?>style="display:none;" <?php endif; ?>>

</div>