<?php if (!defined('THINK_PATH')) exit(); /*a:9:{s:36:"template/stui_tpl/html/vod/show.html";i:1550496530;s:67:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/seo/vod_show.html";i:1705130310;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/include.html";i:1705074684;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/head.html";i:1705075051;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/vod_box.html";i:1550318930;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/page.html";i:1539164316;s:64:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/hot.html";i:1550494458;s:73:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/vod_box_rank.html";i:1550320472;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/foot.html";i:1705074233;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>最新<?php echo $obj['type_name']; ?>-推荐<?php echo $obj['type_name']; ?> - <?php echo $maccms['seo']['vod']['name']; ?></title>
<meta name="keywords" content="<?php echo $obj['type_key']; ?>" />
<meta name="description" content="<?php echo $obj['type_des']; ?>" />   
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="/statics/img/favicon.ico" type="image/x-icon" />	
<link rel="stylesheet" href="/statics/font/iconfont.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block_color.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_default.css" type="text/css" />
<script type="text/javascript" src="//cdn.staticfile.org/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/stui_default.js"></script>
<script type="text/javascript" src="/statics/js/stui_block.js "></script>
<script type="text/javascript" src="/statics/js/home.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
	

</head>
<body>
	<header class="stui-header__top clearfix" id="header-top">
	<div class="container">	
		<div class="row">
			<div class="stui-header_bd clearfix">					
			    <div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"></a>										  
				</div>
				<div class="stui-header__side">					
					<ul class="stui-header__user">
						<?php if($maccms['user_status'] == 1): ?>
						<li>
							<a class="mac_user" href="javascript:;"><i class="icon iconfont icon-account"></i></a>
						</li>
						<?php else: ?>
						<li>
							<a href="javascript:;"><i class="icon iconfont icon-clock"></i></a>
							<div class="dropdown history">					
								<h5 class="margin-0 text-muted">
									<a class="historyclean text-muted pull-right" href="">清空</a>
									播放记录
								</h5>
								<ul class="clearfix" id="stui_history">
								</ul>
							</div>
						</li>
						<?php endif; ?>
					</ul>
					<script type="text/javascript" src="//lf3-cdn-tos.bytecdntp.com/cdn/expire-10-y/jquery-autocomplete/1.0.7/jquery.auto-complete.js"></script>
					<div class="stui-header__search"> 
				        <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();">
	    					<input type="text" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="请输入关键词..." autocomplete="off"/>
							<button class="submit" id="searchbutton" type="submit"><i class="icon iconfont icon-search"></i></button>							
						</form>
				  	</div>
				</div>									
				<ul class="stui-header__menu type-slide">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                <li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
	                <?php endforeach; endif; else: echo "" ;endif; ?>
	                <li <?php if($maccms['aid'] == 30): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_topic_index(); ?>">专题</a></li>
				</ul>				
			  </div>		 							    
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
	});
</script>

    <div class="container">
        <div class="row">
        	<div class="col-lg-wide-75 col-xs-1 padding-0">	
	            <div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">						
						<!-- 筛选 -->		
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">
								<h3 class="title">
									<img src="<?php echo $maccms['path']; ?>statics/icon/icon_27.png"/>
									<?php echo $obj['type_name']; ?>筛选
								</h3>						
							</div>
							<?php if($obj['childids'] != ''): ?>
							<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
								<li>
									<span class="text-muted">按类型</span>
								</li>
								<?php if($obj['type_pid'] == 0): ?>
									<li<?php if($obj['type_pid'] == ''): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj['type_id'],['id'=>$obj['type_id']],'show'); ?>">全部</a></li>
									<?php $__TAG__ = '{"parent":"'.$obj['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
		                        	<li<?php if($obj['type_id'] == $vo2['type_id']): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($vo2,[],'show'); ?>" class="text-muted"><?php echo $vo2['type_name']; ?></a></li>
		                        	<?php endforeach; endif; else: echo "" ;endif; else: ?>
		                        	<li<?php if($obj['type_pid'] == ''): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj['type_pid'],['id'=>$obj['type_pid']],'show'); ?>">全部</a></li>
		                        	<?php $__TAG__ = '{"parent":"'.$obj['type_pid'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?>
		                        	<li<?php if($obj['type_id'] == $vo2['type_id']): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($vo2,[],'show'); ?>" class="text-muted"><?php echo $vo2['type_name']; ?></a></li>
		                        	<?php endforeach; endif; else: echo "" ;endif; endif; ?>												  	
							</ul>
							<?php endif; ?>
							<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
								<li>
									<span class="text-muted">按剧情</span>
								</li>
								<li <?php if($param['class'] == ''): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>'','order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>">全部</a></li>
				                <?php if(empty($obj['type_extend']['area']) || (($obj['type_extend']['area'] instanceof \think\Collection || $obj['type_extend']['area'] instanceof \think\Paginator ) && $obj['type_extend']['area']->isEmpty())): $_65a239482965d=explode(',',$obj['parent']['type_extend']['class']); if(is_array($_65a239482965d) || $_65a239482965d instanceof \think\Collection || $_65a239482965d instanceof \think\Paginator): if( count($_65a239482965d)==0 ) : echo "" ;else: foreach($_65a239482965d as $key2=>$vo2): ?>
				                <li <?php if($param['class'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$vo2,'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                <?php endforeach; endif; else: echo "" ;endif; else: $_65a2394829636=explode(',',$obj['type_extend']['class']); if(is_array($_65a2394829636) || $_65a2394829636 instanceof \think\Collection || $_65a2394829636 instanceof \think\Paginator): if( count($_65a2394829636)==0 ) : echo "" ;else: foreach($_65a2394829636 as $key2=>$vo2): ?>
				                <li <?php if($param['class'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$vo2,'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                <?php endforeach; endif; else: echo "" ;endif; endif; ?>							
							</ul>
							<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
								<li>
									<span class="text-muted">按地区</span>
								</li>
								<li <?php if($param['area'] == ''): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>'','lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>">全部</a></li>
				                <?php if(empty($obj['type_extend']['area']) || (($obj['type_extend']['area'] instanceof \think\Collection || $obj['type_extend']['area'] instanceof \think\Paginator ) && $obj['type_extend']['area']->isEmpty())): $_65a23948295dd=explode(',',$obj['parent']['type_extend']['area']); if(is_array($_65a23948295dd) || $_65a23948295dd instanceof \think\Collection || $_65a23948295dd instanceof \think\Paginator): if( count($_65a23948295dd)==0 ) : echo "" ;else: foreach($_65a23948295dd as $key2=>$vo2): ?>
				                    <li <?php if($param['area'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$vo2,'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; else: $_65a23948295b2=explode(',',$obj['type_extend']['area']); if(is_array($_65a23948295b2) || $_65a23948295b2 instanceof \think\Collection || $_65a23948295b2 instanceof \think\Paginator): if( count($_65a23948295b2)==0 ) : echo "" ;else: foreach($_65a23948295b2 as $key2=>$vo2): ?>
				                    <li <?php if($param['area'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$vo2,'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; endif; ?>
							</ul>
							<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
								<li>
									<span class="text-muted">按年份</span>
								</li>
								<li <?php if($param['year'] == ''): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>'','level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>">全部</a></li>
				                <?php if(empty($obj['type_extend']['year']) || (($obj['type_extend']['year'] instanceof \think\Collection || $obj['type_extend']['year'] instanceof \think\Paginator ) && $obj['type_extend']['year']->isEmpty())): $_65a2394829570=explode(',',$obj['parent']['type_extend']['year']); if(is_array($_65a2394829570) || $_65a2394829570 instanceof \think\Collection || $_65a2394829570 instanceof \think\Paginator): if( count($_65a2394829570)==0 ) : echo "" ;else: foreach($_65a2394829570 as $key2=>$vo2): ?>
				                    <li <?php if($param['year'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$vo2,'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; else: $_65a2394829553=explode(',',$obj['type_extend']['year']); if(is_array($_65a2394829553) || $_65a2394829553 instanceof \think\Collection || $_65a2394829553 instanceof \think\Paginator): if( count($_65a2394829553)==0 ) : echo "" ;else: foreach($_65a2394829553 as $key2=>$vo2): ?>
				                    <li <?php if($param['year'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$vo2,'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; endif; ?>							
							</ul>
							<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
								<li>
									<span class="text-muted">按语言</span>
								</li>
								<li <?php if($param['lang'] == ''): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>'','year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>">全部</a></li>
				                <?php if(empty($obj['type_extend']['lang']) || (($obj['type_extend']['lang'] instanceof \think\Collection || $obj['type_extend']['lang'] instanceof \think\Paginator ) && $obj['type_extend']['lang']->isEmpty())): $_65a2394829510=explode(',',$obj['parent']['type_extend']['lang']); if(is_array($_65a2394829510) || $_65a2394829510 instanceof \think\Collection || $_65a2394829510 instanceof \think\Paginator): if( count($_65a2394829510)==0 ) : echo "" ;else: foreach($_65a2394829510 as $key2=>$vo2): ?>
				                    <li <?php if($param['lang'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$vo2,'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; else: $_65a23948294f2=explode(',',$obj['type_extend']['lang']); if(is_array($_65a23948294f2) || $_65a23948294f2 instanceof \think\Collection || $_65a23948294f2 instanceof \think\Paginator): if( count($_65a23948294f2)==0 ) : echo "" ;else: foreach($_65a23948294f2 as $key2=>$vo2): ?>
				                    <li <?php if($param['lang'] == $vo2): ?> class="active" <?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$vo2,'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a></li>
				                    <?php endforeach; endif; else: echo "" ;endif; endif; ?>							
							</ul>
							<ul class="stui-screen__list letter-list type-slide clearfix">
								<li>
									<span class="text-muted">按字母</span>
								</li>
								<li <?php if($param['letter'] == ''): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>'','state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>">全部</a></li>
				                <?php $_65a23948294a1=explode(',','A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0-9'); if(is_array($_65a23948294a1) || $_65a23948294a1 instanceof \think\Collection || $_65a23948294a1 instanceof \think\Paginator): if( count($_65a23948294a1)==0 ) : echo "" ;else: foreach($_65a23948294a1 as $key2=>$vo2): ?>
				                <li <?php if($param['letter'] == $vo2): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$vo2,'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>$param['by'] ],'show'); ?>"><?php echo $vo2; ?></a><li>
				                <?php endforeach; endif; else: echo "" ;endif; ?>							
							</ul>			
						</div>
						<!-- end 筛选 -->
					</div>
				</div>
				<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						
						<!-- 排序 -->		
						<div class="stui-pannel_hd">
							<div class="stui-pannel__head active bottom-line clearfix">
								<ul class="nav nav-head">
									<li <?php if($param['by'] == '' || $param['by'] == 'time'): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'time' ],'show'); ?>">按时间</a></li>
							        <li <?php if($param['by'] == 'hits'): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'hits' ],'show'); ?>">按人气</a></li>
							        <li <?php if($param['by'] == 'score'): ?> class="active"<?php endif; ?>><a href="<?php echo mac_url_type($obj,['area'=>$param['area'],'lang'=>$param['lang'],'year'=>$param['year'],'level'=>$param['level'],'letter'=>$param['letter'],'state'=>$param['state'],'tag'=>$param['tag'],'class'=>$param['class'],'order'=>$param['order'],'by'=>'score' ],'show'); ?>">按评分</a></li>
								</ul>																
							</div>	
						</div>
						<!-- end 排序 -->		
						
						<div class="stui-pannel_bd">
							<ul class="stui-vodlist clearfix">
								<?php $__TAG__ = '{"num":"36","paging":"yes","pageurl":"vod\/show","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
								<li class="col-md-6 col-sm-4 col-xs-3">
									<div class="stui-vodlist__box">
	<a class="stui-vodlist__thumb lazyload" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>">						
		<span class="play hidden-xs"></span>		
		<span class="pic-text text-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
	</a>									
	<div class="stui-vodlist__detail">
		<h4 class="title text-overflow"><a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a></h4>
		<p class="text text-overflow text-muted hidden-xs"><?php echo mac_default($vo['vod_actor'],'内详'); ?></p>
	</div>												
</div>	<!-- 列表-->															
								</li>
								 <?php endforeach; endif; else: echo "" ;endif; ?>
							</ul>	
						</div>						
					</div>				
				</div>		
				<?php if($__PAGING__['page_total'] > 1): ?>
<ul class="stui-page text-center clearfix">
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a></li>							
	<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
	<li class="hidden-xs <?php if($__PAGING__['page_current'] == $num): ?>active<?php endif; ?>"><a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li class="active visible-xs"><span class="num"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></span></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a></li>							
</ul>
<?php endif; ?><!-- 翻页-->		
			</div>				
			<div class="col-lg-wide-25 col-xs-1 stui-pannel-side hidden-sm hidden-xs padding-0">	
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_12.png"/>
					<?php echo $obj['type_name']; ?>周榜单
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__text col-pd clearfix">
				<?php $__TAG__ = '{"num":"20","type":"'.$obj['type_id'].'","order":"desc","by":"hitsweek","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li class="bottom-line-dot">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="text-muted pull-right hidden-md">
			<?php if($vo['vod_remarks'] != ''): ?><?php echo mac_substring($vo['vod_remarks'],8); elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
		</span>
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo mac_substring($vo['vod_name'],8); ?></a>
</li>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>	
		</div>
	</div>
</div>

<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_12.png"/>
					<?php echo $obj['type_name']; ?>月榜单
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__text col-pd clearfix">
				<?php $__TAG__ = '{"num":"20","type":"'.$obj['type_id'].'","order":"desc","by":"hitsmonth","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li class="bottom-line-dot">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="text-muted pull-right hidden-md">
			<?php if($vo['vod_remarks'] != ''): ?><?php echo mac_substring($vo['vod_remarks'],8); elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
		</span>
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo mac_substring($vo['vod_name'],8); ?></a>
</li>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>	
		</div>
	</div>
</div><!-- 热播-->				
			</div>
        </div>
    </div>
	<div class="container">
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center hidden-xs"><span class="fontArial"> </span> 本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</a><br>
			<div class="col-pd text-center hidden-xs">联系邮箱：<a href="mailto:{maccms:email}"><?php echo $maccms['site_email']; ?></a></div>	</div>
			
			<p class="text-center hidden-xs">

			</p>			
			<p class="text-muted text-center visible-xs">Copyright © 2008-2018</p>
		</div>
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;"><i class="icon iconfont icon-less"></i></a>
	</li>
	<li class="hidden-xs">
		<a class="copylink" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="visible-xs">
		<a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="hidden-xs">
		<span><i class="icon iconfont icon-qrcode"></i></span>
		<div class="sideslip">
			<div class="col-pd">
				<p id="qrcode"></p>
				<p class="text-center font-12">扫码用手机访问</p>
			</div>			
		</div>
	</li>
	<li>
		<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i></a>
	</li>
</ul>

<div class="hide"><?php echo $maccms['site_tj']; ?></div>
</body>
</html>
