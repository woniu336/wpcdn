<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:39:"template/stui_tpl/html/gbook/index.html";i:1545943070;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/include.html";i:1705074684;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/head.html";i:1705075051;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/page.html";i:1539164316;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/foot.html";i:1705074233;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width = device-width ,initial-scale = 1,minimum-scale = 1,maximum-scale = 1,user-scalable =no,"/>
    <title>留言板 - <?php echo $maccms['site_name']; ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="/statics/img/favicon.ico" type="image/x-icon" />	
<link rel="stylesheet" href="/statics/font/iconfont.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block_color.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_default.css" type="text/css" />
<script type="text/javascript" src="//cdn.staticfile.org/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/stui_default.js"></script>
<script type="text/javascript" src="/statics/js/stui_block.js "></script>
<script type="text/javascript" src="/statics/js/home.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
	

    <script>
        $(function(){
            MAC.Gbook.Login = <?php echo $gbook['login']; ?>;
            MAC.Gbook.Verify = <?php echo $gbook['verify']; ?>;
            MAC.Gbook.Init();
        });
    </script>
</head>
<body>
<header class="stui-header__top clearfix" id="header-top">
	<div class="container">	
		<div class="row">
			<div class="stui-header_bd clearfix">					
			    <div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"></a>										  
				</div>
				<div class="stui-header__side">					
					<ul class="stui-header__user">
						<?php if($maccms['user_status'] == 1): ?>
						<li>
							<a class="mac_user" href="javascript:;"><i class="icon iconfont icon-account"></i></a>
						</li>
						<?php else: ?>
						<li>
							<a href="javascript:;"><i class="icon iconfont icon-clock"></i></a>
							<div class="dropdown history">					
								<h5 class="margin-0 text-muted">
									<a class="historyclean text-muted pull-right" href="">清空</a>
									播放记录
								</h5>
								<ul class="clearfix" id="stui_history">
								</ul>
							</div>
						</li>
						<?php endif; ?>
					</ul>
					<script type="text/javascript" src="//lf3-cdn-tos.bytecdntp.com/cdn/expire-10-y/jquery-autocomplete/1.0.7/jquery.auto-complete.js"></script>
					<div class="stui-header__search"> 
				        <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();">
	    					<input type="text" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="请输入关键词..." autocomplete="off"/>
							<button class="submit" id="searchbutton" type="submit"><i class="icon iconfont icon-search"></i></button>							
						</form>
				  	</div>
				</div>									
				<ul class="stui-header__menu type-slide">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                <li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
	                <?php endforeach; endif; else: echo "" ;endif; ?>
	                <li <?php if($maccms['aid'] == 30): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_topic_index(); ?>">专题</a></li>
				</ul>				
			  </div>		 							    
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
	});
</script>
 
<div class="container">
    <div class="row">
	    <div class="col-lg-wide-3 col-xs-1">
	     	<div class="stui-pannel stui-pannel-bg clearfix">
	     		<div class="stui-pannel-box clearfix"> 
	     			<div class="stui-pannel_hd">
						<div class="stui-pannel__head clearfix">
							<h3 class="title">
								我要留言
							</h3>						
						</div>																		
					</div>
	     			<div class="col-pd clearfix">
	     				 <form class="gbook_form">   	     					
	     				<ul class="gbook-form">	
							<li>
								<textarea class="form-control" name="gbook_content"></textarea>
							</li>						
							<?php if($gbook['verify'] == 1): ?>
							<li>
								<input type="text" name="verify" class="mac_verify form-control" placeholder="验证码" style="width: 80px; display: inline-block; margin-right: 10px;">
							</li>
							<?php endif; ?>
							<li>
								<input class="btn btn-primary pull-right gbook_submit"type="button" value="提交" ><input type="reset" value="重新留言" class="btn btn-default" />
							</li>
	     				</ul>
	     				</form>
	     			</div>
	     		</div>
	     	</div>
	    </div>
	    <div class="col-lg-wide-7 col-xs-1">
			<?php $__TAG__ = '{"num":"10","paging":"yes","order":"desc","by":"id","id":"vo","key":"key"}';$__LIST__ = model("Gbook")->listCacheData($__TAG__);$__PAGING__ = mac_page_param($__LIST__['total'],$__LIST__['limit'],$__LIST__['page'],$__LIST__['pageurl'],$__LIST__['half']); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	    	<div class="stui-pannel stui-pannel-bg clearfix">
	    		<div class="stui-pannel-box clearfix">
	    			<div class="col-pd">
	    				<div class="bottom-line">
	    					<span class="text-muted pull-right"><?php echo mac_long2ip($vo['gbook_ip']); ?></span>
	    					<h4 class="title" style=" margin: 0 0 10px; padding-bottom: 10px;"><?php echo $vo['gbook_name']; ?></h4>
	    				</div>
	    				<p class="con"><?php echo $vo['gbook_content']; ?></p>
	    				<?php if($vo['gbook_reply_time'] > 0): ?>
						<p class="text-red">管理员回复：<?php echo $vo['gbook_reply']; ?></p>
						<?php endif; ?>
	    				<p class="text-muted font-12"><?php echo date('Y-m-d H:i:s',$vo['gbook_time']); ?></p>													
	    			</div>   	    			  	    			
	    		</div>
	    	</div>
	    	<?php endforeach; endif; else: echo "" ;endif; if($__PAGING__['page_total'] > 1): ?>
<ul class="stui-page text-center clearfix">
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],1); ?>">首页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_prev']); ?>">上一页</a></li>							
	<?php if(is_array($__PAGING__['page_num']) || $__PAGING__['page_num'] instanceof \think\Collection || $__PAGING__['page_num'] instanceof \think\Paginator): if( count($__PAGING__['page_num'])==0 ) : echo "" ;else: foreach($__PAGING__['page_num'] as $key=>$num): ?>
	<li class="hidden-xs <?php if($__PAGING__['page_current'] == $num): ?>active<?php endif; ?>"><a href="<?php echo mac_url_page($__PAGING__['page_url'],$num); ?>"><?php echo $num; ?></a></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li class="active visible-xs"><span class="num"><?php echo $__PAGING__['page_current']; ?>/<?php echo $__PAGING__['page_total']; ?></span></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_next']); ?>">下一页</a></li>
	<li><a href="<?php echo mac_url_page($__PAGING__['page_url'],$__PAGING__['page_total']); ?>">尾页</a></li>							
</ul>
<?php endif; ?>
	    </div>
    </div>
</div>
<style type="text/css">
	.gbook-form li{ margin-bottom: 15px;}
	.gbook-form li:last-child{ margin-bottom: 0;}
</style>
<div class="container">
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center hidden-xs"><span class="fontArial"> </span> 本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</a><br>
			<div class="col-pd text-center hidden-xs">联系邮箱：<a href="mailto:{maccms:email}"><?php echo $maccms['site_email']; ?></a></div>	</div>
			
			<p class="text-center hidden-xs">

			</p>			
			<p class="text-muted text-center visible-xs">Copyright © 2008-2018</p>
		</div>
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;"><i class="icon iconfont icon-less"></i></a>
	</li>
	<li class="hidden-xs">
		<a class="copylink" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="visible-xs">
		<a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="hidden-xs">
		<span><i class="icon iconfont icon-qrcode"></i></span>
		<div class="sideslip">
			<div class="col-pd">
				<p id="qrcode"></p>
				<p class="text-center font-12">扫码用手机访问</p>
			</div>			
		</div>
	</li>
	<li>
		<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i></a>
	</li>
</ul>

<div class="hide"><?php echo $maccms['site_tj']; ?></div>
</body>
</html>