<?php if (!defined('THINK_PATH')) exit(); /*a:12:{s:38:"template/stui_tpl/html/vod/detail.html";i:1550497076;s:69:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/seo/vod_detail.html";i:1705127728;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/include.html";i:1705074684;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/head.html";i:1705075051;s:67:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/vod/playlist.html";i:1550323350;s:63:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/vod/desc.html";i:1550497046;s:63:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/vod/like.html";i:1550494938;s:68:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/vod_box.html";i:1550318930;s:63:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/vod/code.html";i:1550322130;s:62:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/vod/hot.html";i:1551248692;s:73:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/vod_box_rank.html";i:1550320472;s:65:"/www/wwwroot/wan.51la.link/template/stui_tpl/html/block/foot.html";i:1705131122;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $obj['vod_name']; ?>高清全集免费在线观看-<?php echo $obj['type']['type_name']; ?> - <?php echo $maccms['seo']['vod']['name']; ?></title>
<meta name="keywords" content="<?php echo $obj['vod_name']; ?>在线收看,<?php echo $obj['vod_name']; ?>迅雷下载" />
<meta name="description" content="<?php echo $obj['vod_name']; ?>剧情:<?php echo $obj['vod_blurb']; ?>" />   
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="/statics/img/favicon.ico" type="image/x-icon" />	
<link rel="stylesheet" href="/statics/font/iconfont.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_block_color.css" type="text/css" />
<link rel="stylesheet" href="/statics/css/stui_default.css" type="text/css" />
<script type="text/javascript" src="//cdn.staticfile.org/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/stui_default.js"></script>
<script type="text/javascript" src="/statics/js/stui_block.js "></script>
<script type="text/javascript" src="/statics/js/home.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
	

</head>
<body>
	<header class="stui-header__top clearfix" id="header-top">
	<div class="container">	
		<div class="row">
			<div class="stui-header_bd clearfix">					
			    <div class="stui-header__logo">
					<a class="logo" href="<?php echo $maccms['path']; ?>"></a>										  
				</div>
				<div class="stui-header__side">					
					<ul class="stui-header__user">
						<?php if($maccms['user_status'] == 1): ?>
						<li>
							<a class="mac_user" href="javascript:;"><i class="icon iconfont icon-account"></i></a>
						</li>
						<?php else: ?>
						<li>
							<a href="javascript:;"><i class="icon iconfont icon-clock"></i></a>
							<div class="dropdown history">					
								<h5 class="margin-0 text-muted">
									<a class="historyclean text-muted pull-right" href="">清空</a>
									播放记录
								</h5>
								<ul class="clearfix" id="stui_history">
								</ul>
							</div>
						</li>
						<?php endif; ?>
					</ul>
					<script type="text/javascript" src="//lf3-cdn-tos.bytecdntp.com/cdn/expire-10-y/jquery-autocomplete/1.0.7/jquery.auto-complete.js"></script>
					<div class="stui-header__search"> 
				        <form id="search" name="search" method="get" action="<?php echo mac_url('vod/search'); ?>" onSubmit="return qrsearch();">
	    					<input type="text" name="wd" class="mac_wd form-control" value="<?php echo $param['wd']; ?>" placeholder="请输入关键词..." autocomplete="off"/>
							<button class="submit" id="searchbutton" type="submit"><i class="icon iconfont icon-search"></i></button>							
						</form>
				  	</div>
				</div>									
				<ul class="stui-header__menu type-slide">
					<li <?php if($maccms['aid'] == 1): ?>class="active"<?php endif; ?>><a href="<?php echo $maccms['path']; ?>">首页</a></li>
					<?php $__TAG__ = '{"num":"10","order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
	                <li <?php if(($vo['type_id'] == $GLOBALS['type_id'] || $vo['type_id'] == $GLOBALS['type_pid'])): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
	                <?php endforeach; endif; else: echo "" ;endif; ?>
	                <li <?php if($maccms['aid'] == 30): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_topic_index(); ?>">专题</a></li>
				</ul>				
			  </div>		 							    
		</div>
	</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
	});
</script>

    <div class="container">
        <div class="row">     
            <div class="col-lg-wide-75 col-xs-1 padding-0">	
            	<!-- 详细信息-->
            	<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box">
						<div class="col-pd clearfix">	
							<span class="text-muted">当前位置 <i class="icon iconfont icon-more"></i></span>
							<a href="<?php echo $maccms['path']; ?>">首页</a> <i class="icon iconfont icon-more"></i>
							<a href="<?php echo mac_url_type($obj,[],'show'); ?>"><?php echo $obj['type']['type_name']; ?></a> <i class="icon iconfont icon-more"></i> 
							<span class="text-muted">《<?php echo $obj['vod_name']; ?>》</span> 
						</div>
						<div class="col-pd clearfix">
							<div class="stui-content__thumb">									
								<a class="stui-vodlist__thumb picture v-thumb" href="<?php echo mac_url_vod_play($obj,['sid'=>1,'nid'=>1]); ?>" title="<?php echo $obj['vod_name']; ?>">
									<img class="lazyload" src="<?php echo $maccms['path']; ?>statics/img/load.gif" data-original="<?php echo mac_url_img($obj['vod_pic']); ?>"/>
									<span class="play active hidden-xs"></span>
									<span class="pic-text text-right"><?php if($obj['vod_remarks'] != ''): ?><?php echo $obj['vod_remarks']; elseif($obj['vod_serial'] > 0): ?>第<?php echo $obj['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
								</a>					
							</div>
							<div class="stui-content__detail">
								<h1 class="title"><?php echo $obj['vod_name']; ?><span class="score text-red"><?php echo $obj['vod_score']; ?></span></h1>	
								<p class="data">
									<span class="text-muted">类型：</span><?php echo mac_url_create($obj['vod_class'],'class'); ?>
									<span class="split-line"></span>
									<span class="text-muted hidden-xs">地区：</span><?php echo mac_url_create($obj['vod_area'],'area'); ?>
									<span class="split-line"></span>
									<span class="text-muted hidden-xs">年份：</span><?php echo mac_url_create($obj['vod_year'],'year'); ?>								
								</p>
								<p class="data"><span class="text-muted">主演：</span><?php echo mac_url_create(mac_substring($obj['vod_actor'],35),'actor'); ?></p>
								<p class="data"><span class="text-muted">导演：</span><?php echo mac_url_create($obj['vod_director'],'director'); ?></p>
								<p class="data hidden-sm"><span class="text-muted">更新：</span><?php echo date('Y-m-d',$obj['vod_time']); ?></p>														
								<p class="desc hidden-xs">
									<span class="left text-muted">简介：</span>
									<?php echo mac_substring(mac_filter_html($obj['vod_content']),80); ?>
									<a href="#desc">详情 <i class="icon iconfont icon-moreunfold"></i></a>
								</p>							    
								<div class="play-btn clearfix">
									<div class="share bdsharebuttonbox hidden-sm hidden-xs pull-right"></div>
									<a class="btn btn-primary" href="<?php echo mac_url_vod_play($obj,['sid'=>1,'nid'=>1]); ?>">立即播放</a>
									<?php if($maccms['user_status'] == 1): ?>								
									&nbsp;&nbsp;<a href="javascript:void(0);" class="mac_ulog btn btn-default" data-type="2" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>">收藏</a>
									<?php endif; ?>										
									<!--<span class="bdsharebuttonbox hidden-xs"><a href="javascript:;" class="btn btn-default bds_btn" data-cmd="more">分享</a></span>-->
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- end 详细信息-->
				
				<?php if(is_array($obj['vod_play_list']) || $obj['vod_play_list'] instanceof \think\Collection || $obj['vod_play_list'] instanceof \think\Paginator): if( count($obj['vod_play_list'])==0 ) : echo "" ;else: foreach($obj['vod_play_list'] as $key=>$vo): ?>
<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box b playlist mb">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head bottom-line active clearfix">
				<span class="more text-muted pull-right"><?php echo $vo['player_info']['tip']; ?></span>
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_30.png"/>
					<?php echo $vo['player_info']['show']; ?>
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd col-pd clearfix">
			<ul class="stui-content__playlist clearfix">
				<?php if(is_array($vo['urls']) || $vo['urls'] instanceof \think\Collection || $vo['urls'] instanceof \think\Paginator): if( count($vo['urls'])==0 ) : echo "" ;else: foreach($vo['urls'] as $key=>$vo2): ?>
                <li <?php if($param['sid'] == $vo['sid'] && $param['nid'] == $vo2['nid']): ?>class="active"<?php endif; ?>><a href="<?php echo mac_url_vod_play($obj,['sid'=>$vo['sid'],'nid'=>$vo2['nid']]); ?>"><?php echo $vo2['name']; ?></a></li>
                 <?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
<!-- 播放地址-->
				<div class="stui-pannel stui-pannel-bg clearfix" id="desc">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_30.png"/>
					剧情简介
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<p class="col-pd">
				<?php echo mac_filter_html($obj['vod_content']); ?>
			</p>				
		</div>			
	</div>						
</div><!-- 剧情简介-->
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_6.png"/>
					猜你喜欢
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__bd clearfix">
				<?php $__TAG__ = '{"num":"12","type":"current","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<li class="col-md-6 col-sm-4 col-xs-3 <?php if($key > 8): ?>hidden-md<?php endif; ?>">
					<div class="stui-vodlist__box">
	<a class="stui-vodlist__thumb lazyload" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>">						
		<span class="play hidden-xs"></span>		
		<span class="pic-text text-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
	</a>									
	<div class="stui-vodlist__detail">
		<h4 class="title text-overflow"><a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>"><?php echo $vo['vod_name']; ?></a></h4>
		<p class="text text-overflow text-muted hidden-xs"><?php echo mac_default($vo['vod_actor'],'内详'); ?></p>
	</div>												
</div>															
				</li>			
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>	
			<ul class="stui-vodlist__text col-pd clearfix hidden-xs">
				<?php $__TAG__ = '{"num":"20","type":"current","order":"desc","by":"time","start":"13","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
				<li class="col-md-4 col-sm-3 col-xs-1 padding-0">
					<a class="top-line-dot text-overflow" href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
						<span class="text-muted pull-right"><?php if($vo['vod_remarks'] != ''): ?><?php echo $vo['vod_remarks']; elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?></span>
						<?php echo mac_substring($vo['vod_name'],12); ?>
					</a>									
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>			
	</div>						
</div>
<!-- 猜你喜欢-->
				
				<?php if($comment['status'] == 1): ?>
				<div class="stui-pannel stui-pannel-bg clearfix">
					<div class="stui-pannel-box clearfix">
						<div class="stui-pannel_bd clearfix">
							<div class="stui-pannel_hd">
								<div class="stui-pannel__head active bottom-line clearfix">
									<h3 class="title">
										<img src="<?php echo $maccms['path']; ?>statics/icon/icon_30.png"/>
										影片评论
									</h3>						
								</div>																		
							</div>
							<div class="stui-pannel_bd">
								<div class="mac_comment" data-id="<?php echo $obj['vod_id']; ?>" data-mid="<?php echo $maccms['mid']; ?>" ></div>
								<script>
							        $(function(){
							            MAC.Comment.Login = <?php echo $comment['login']; ?>;
							            MAC.Comment.Verify = <?php echo $comment['verify']; ?>;
							            MAC.Comment.Init();
							            MAC.Comment.Show(1);
							        });
							    </script>
							</div>
						</div>
					</div>					
				</div>		
				<?php endif; ?>
			</div>				
			<div class="col-lg-wide-25 col-xs-1 stui-pannel-side hidden-sm hidden-xs">	
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box clearfix">
		<div class="col-pd">
			<div class="text-center" style="padding: 45px 0; border: 1px solid #eee; border-radius: 5px;">
				<p id="qrcode2"></p>	
				<p>扫描二维码用手机观看</p>
			</div>
		</div>
		
	</div>
</div><!-- 扫码-->
				<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_12.png"/>
					<?php echo $obj['type']['type_name']; ?>周榜单
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__text col-pd clearfix">
				<?php $__TAG__ = '{"num":"10","type":"current","order":"desc","by":"hits_week","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li class="bottom-line-dot">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="text-muted pull-right hidden-md">
			<?php if($vo['vod_remarks'] != ''): ?><?php echo mac_substring($vo['vod_remarks'],8); elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
		</span>
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo mac_substring($vo['vod_name'],8); ?></a>
</li>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>	
		</div>
	</div>
</div>

<div class="stui-pannel stui-pannel-bg clearfix">
	<div class="stui-pannel-box">
		<div class="stui-pannel_hd">
			<div class="stui-pannel__head active bottom-line clearfix">
				<h3 class="title">
					<img src="<?php echo $maccms['path']; ?>statics/icon/icon_12.png"/>
					<?php echo $obj['type']['type_name']; ?>月榜单
				</h3>						
			</div>																		
		</div>
		<div class="stui-pannel_bd">
			<ul class="stui-vodlist__text col-pd clearfix">
				<?php $__TAG__ = '{"num":"10","type":"current","order":"desc","by":"hits_month","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<li class="bottom-line-dot">
	<a href="<?php echo mac_url_vod_detail($vo); ?>" title="<?php echo $vo['vod_name']; ?>">
		<span class="text-muted pull-right hidden-md">
			<?php if($vo['vod_remarks'] != ''): ?><?php echo mac_substring($vo['vod_remarks'],8); elseif($vo['vod_serial'] > 0): ?>第<?php echo $vo['vod_serial']; ?>集<?php else: ?>已完结<?php endif; ?>
		</span>
		<span class="badge<?php if($key == 1): ?> badge-first<?php endif; if($key == 2): ?> badge-second<?php endif; if($key == 3): ?> badge-third<?php endif; ?>"><?php echo $key; ?></span><?php echo mac_substring($vo['vod_name'],8); ?></a>
</li>	
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>	
		</div>
	</div>
</div><!-- 热播-->				
			</div>
        </div>
    </div>
    <script type="text/javascript">
    	var playli = $(".stui-content__playlist:first li").length;
    	if(playcolumn>1){  		  		
    		if(playli>5){
    			$(".stui-content__playlist").addClass("column"+playcolumn);
    		}   		
    	}
    	if(playli>30){
			$(".stui-content__playlist").css({"max-height":" 300px","overflow-y":"scroll"});
		} 
    </script>
	<span class="mac_hits hits hide" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?><?php echo $obj['art_id']; ?><?php echo $obj['topic_id']; ?>" data-type="hits"></span>
    <span class="mac_ulog_set hide" data-type="4" data-mid="<?php echo $maccms['mid']; ?>" data-id="<?php echo $obj['vod_id']; ?>" data-sid="<?php echo $param['sid']; ?>" data-nid="<?php echo $param['nid']; ?>"></span>
	<div class="container">
	<div class="row">
		<div class="stui-foot clearfix">
			<div class="col-pd text-center hidden-xs"><span class="fontArial"> </span> 本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</a><br>
			<div class="col-pd text-center hidden-xs">联系邮箱：<a href="mailto:{maccms:email}"><?php echo $maccms['site_email']; ?></a></div>	</div>
			
			<p class="text-center hidden-xs">

			</p>			
			<p class="text-muted text-center visible-xs">本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。</p>
		</div>
	</div>
</div>
<ul class="stui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" style="display: none;"><i class="icon iconfont icon-less"></i></a>
	</li>
	<li class="hidden-xs">
		<a class="copylink" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="visible-xs">
		<a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a>
	</li>
	<li class="hidden-xs">
		<span><i class="icon iconfont icon-qrcode"></i></span>
		<div class="sideslip">
			<div class="col-pd">
				<p id="qrcode"></p>
				<p class="text-center font-12">扫码用手机访问</p>
			</div>			
		</div>
	</li>
	<li>
		<a href="<?php echo mac_url('gbook/index'); ?>"><i class="icon iconfont icon-comments"></i></a>
	</li>
</ul>

<div class="hide"><?php echo $maccms['site_tj']; ?></div>
</body>
</html>
