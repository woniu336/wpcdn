<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"/www/wwwroot/wan.51la.link/application/admin/view/system/configupload.html";i:1638900274;s:66:"/www/wwwroot/wan.51la.link/application/admin/view/public/head.html";i:1638900274;s:66:"/www/wwwroot/wan.51la.link/application/admin/view/public/foot.html";i:1638900274;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php echo $title; ?> - <?php echo lang('admin/public/head/title'); ?></title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/admin_style.css?<?php echo $MAC_VERSION; ?>">
    <script type="text/javascript" src="/static/js/jquery.js"></script>
    <script type="text/javascript" src="/static/layui/layui.js"></script>
    <script>
        var ROOT_PATH="",ADMIN_PATH="<?php echo $_SERVER['SCRIPT_NAME']; ?>", MAC_VERSION="v10";
    </script>
</head>
<body>

<div class="page-container">

    <div class="showpic" style="display:none;"><img class="showpic_img" width="120" height="160" referrerPolicy="no-referrer"></div>

    <form class="layui-form layui-form-pane" action="">
        <input type="hidden" name="__token__" value="<?php echo \think\Request::instance()->token(); ?>" />
        <div class="layui-tab">
            <ul class="layui-tab-title">
                <li class="layui-this"><?php echo lang('admin/system/configupload/title'); ?></li>
            </ul>
            <div class="layui-tab-content">

                <div class="layui-tab-item layui-show">

                    <blockquote class="layui-elem-quote layui-quote-nm">
                        <?php echo lang('admin/system/configupload/tip'); ?><?php echo sys_get_temp_dir(); ?><br>
                        <?php
                        $temp_file = tempnam(sys_get_temp_dir(), 'Tux');
                        if($temp_file){
                            echo '<span class="layui-badge layui-bg-green">'.lang('admin/system/configupload/write_ok').'</span>';
                        }
                        else{
                            echo '<span class="layui-badge">'.lang('admin/system/configupload/write_err').'</span>';
                        }
                      ?>
                    </blockquote>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/img_key'); ?>：</label>
                        <div class="layui-input-inline w500">
                            <input type="text" name="upload[img_key]" placeholder="" value="<?php echo $config['upload']['img_key']; ?>" class="layui-input">
                        </div>
                        <div class="layui-form-mid layui-word-aux"><?php echo lang('admin/system/configupload/img_key_tip'); ?></div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/img_api'); ?>：</label>
                        <div class="layui-input-inline w500">
                            <input type="text" name="upload[img_api]" placeholder="" value="<?php echo $config['upload']['img_api']; ?>" class="layui-input">
                        </div>
                        <div class="layui-form-mid layui-word-aux"><?php echo lang('admin/system/configupload/img_api_tip'); ?></div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('pic_thumb'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="radio" name="upload[thumb]" value="0" title="<?php echo lang('close'); ?>" <?php if($config['upload']['thumb'] != 1): ?>checked <?php endif; ?>>
                            <input type="radio" name="upload[thumb]" value="1" title="<?php echo lang('open'); ?>" <?php if($config['upload']['thumb'] == 1): ?>checked <?php endif; ?>>
                        </div>
                        <div class="layui-form-mid layui-word-aux"><?php echo lang('admin/system/configupload/thumb_tip'); ?></div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/thumb_size'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="text" name="upload[thumb_size]" placeholder="" value="<?php echo $config['upload']['thumb_size']; ?>" class="layui-input w150">
                        </div>
                        <div class="layui-form-mid layui-word-aux"><?php echo lang('admin/system/configupload/thumb_size_tip'); ?></div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/thumb_type'); ?>：</label>
                        <div class="layui-input-inline">
                            <select class="w150" name="upload[thumb_type]">
                                <option value="1" <?php if($config['upload']['thumb_type'] == 1): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type1'); ?></option>
                                <option value="2" <?php if($config['upload']['thumb_type'] == 2): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type2'); ?></option>
                                <option value="3" <?php if($config['upload']['thumb_type'] == 3): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type3'); ?></option>
                                <option value="4" <?php if($config['upload']['thumb_type'] == 4): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type4'); ?></option>
                                <option value="5" <?php if($config['upload']['thumb_type'] == 5): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type5'); ?></option>
                                <option value="6" <?php if($config['upload']['thumb_type'] == 6): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/thumb_type6'); ?></option>
                            </select>
                        </div>
                        <div class="layui-form-mid layui-word-aux"></div>
                    </div>
                <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/watermark'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="radio" name="upload[watermark]" value="0" title="<?php echo lang('close'); ?>" <?php if($config['upload']['watermark'] != 1): ?>checked <?php endif; ?>>
                            <input type="radio" name="upload[watermark]" value="1" title="<?php echo lang('open'); ?>" <?php if($config['upload']['watermark'] == 1): ?>checked <?php endif; ?>>
                        </div>
                </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/watermark_location'); ?>：</label>
                        <div class="layui-input-inline">
                            <select class="w150" name="upload[watermark_location]">

                                <option value="1" <?php if($config['upload']['watermark_location'] == 1): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location1'); ?></option>
                                <option value="2" <?php if($config['upload']['watermark_location'] == 2): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location2'); ?></option>
                                <option value="3" <?php if($config['upload']['watermark_location'] == 3): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location3'); ?></option>
                                <option value="4" <?php if($config['upload']['watermark_location'] == 4): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location4'); ?></option>
                                <option value="5" <?php if($config['upload']['watermark_location'] == 5): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location5'); ?></option>
                                <option value="6" <?php if($config['upload']['watermark_location'] == 6): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location6'); ?></option>
                                <option value="7" <?php if($config['upload']['watermark_location'] == 7): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location7'); ?></option>
                                <option value="8" <?php if($config['upload']['watermark_location'] == 8): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location8'); ?></option>
                                <option value="9" <?php if($config['upload']['watermark_location'] == 9): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/watermark_location9'); ?></option>


                            </select>
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/watermark_content'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="text" name="upload[watermark_content]" placeholder="" value="<?php echo $config['upload']['watermark_content']; ?>" class="layui-input w150"  >
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/watermark_size'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="text" name="upload[watermark_size]" placeholder="<?php echo lang('admin/system/configupload/watermark_size_tip'); ?>" value="<?php echo $config['upload']['watermark_size']; ?>" class="layui-input w150"  >
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/watermark_color'); ?>：</label>
                        <div class="layui-input-inline">
                            <input type="text" name="upload[watermark_color]" placeholder="<?php echo lang('admin/system/configupload/watermark_color_tip'); ?>" value="<?php echo $config['upload']['watermark_color']; ?>" class="layui-input w150"  >
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <label class="layui-form-label"><?php echo lang('admin/system/configupload/protocol'); ?>：</label>
                        <div class="layui-input-inline">
                            <select class="w150" name="upload[protocol]" lay-filter="upload[protocol]">
                                <option value="http" <?php if($config['upload']['protocol'] == 'http'): ?>selected <?php endif; ?>>http</option>
                                <option value="https" <?php if($config['upload']['protocol'] == 'https'): ?>selected <?php endif; ?>>https</option>
                            </select>
                        </div>
                        <div class="layui-form-mid layui-word-aux"><?php echo lang('admin/system/configupload/protocol_tip'); ?></div>
                    </div>

                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('admin/system/configupload/mode'); ?>：</label>
                    <div class="layui-input-inline">
                        <select class="w150" name="upload[mode]" lay-filter="upload[mode]">
                            <option value="local" <?php if($config['upload']['mode'] == 'local'): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/mode_local'); ?></option>
                            <option value="remote" <?php if($config['upload']['mode'] == 'remote'): ?>selected <?php endif; ?>><?php echo lang('admin/system/configupload/mode_remote'); ?></option>
                            <?php if(is_array($extends['ext_list']) || $extends['ext_list'] instanceof \think\Collection || $extends['ext_list'] instanceof \think\Paginator): $i = 0; $__LIST__ = $extends['ext_list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo $key; ?>" <?php if($config['upload']['mode'] == $key): ?>selected <?php endif; ?>><?php echo $vo; ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>

                <div class="layui-form-item upload_mode mode_remote" <?php if($config['upload']['mode'] != 'remote'): ?>style="display:none;" <?php endif; ?>>
                    <label class="layui-form-label"><?php echo lang('admin/system/configupload/remoteurl'); ?>：</label>
                    <div class="layui-input-block">
                        <input type="text" name="upload[remoteurl]" placeholder="<?php echo lang('admin/system/configupload/remoteurl_tip'); ?>" value="<?php echo $config['upload']['remoteurl']; ?>" class="layui-input w500">
                    </div>
                </div>

                <?php echo $extends['ext_html']; ?>

                </div>


                <div class="layui-form-item center">
                    <div class="layui-input-block">
                        <button type="submit" class="layui-btn" lay-submit="" lay-filter="formSubmit"><?php echo lang('btn_save'); ?></button>
                        <button class="layui-btn layui-btn-warm" type="reset"><?php echo lang('btn_reset'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript" src="/static/js/admin_common.js?<?php echo $MAC_VERSION; ?>"></script>
<script type="text/javascript">
    layui.use(['form','layer'], function(){
        // 操作对象
        var form = layui.form
                , layer = layui.layer;

        form.on('select(upload[mode])', function(data){
            $('.upload_mode').hide();
            $('.mode_'+ data.value).show();
        });


    });


</script>

</body>
</html>